About this theme
================

This is Bootswatch theme for Moodle.

* package   theme_bootswatch
* copyright 2014 Sonsbeekmedia.nl
* authors   Bas Brands, bas@sonsbeekmedia.nl
* license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later

For more info on Boostrap 3 themes read
https://github.com/bmbrands/theme_bootstrap/blob/master/README.md

This Bootswatches have been created by:

https://github.com/thomaspark/bootswatch
